# coding:utf-8
'''
Created on 2016年12月19日

@author: hao1160
'''

#情感分析的类，使用了分词和贝叶斯算法

import os
import codecs

# import normal
import jieba
from classification.bayes import Bayes

#数据的路径
data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'sentiment.marshal')
stopword_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'stopwords.txt')

#情感分类器
class Sentiment(object):

#初始化，创建一个贝叶斯的对象classifier分类器
    def __init__(self):
        self.classifier = Bayes()
#保存数据classifier对象调用save方法
    def save(self, fname, iszip=True):
        self.classifier.save(fname, iszip)
#读取数据classifier对象调用load方法
    def load(self, fname=data_path, iszip=True):
        self.classifier.load(fname, iszip)
#处理文档的handle方法,下对文档进行分词，然后读取停用词
#将停用词去掉，返回值为序列
    def handle(self, doc):
        words = jieba.cut(doc)
        stopw = [line.strip().decode('utf-8') for line in open(stopword_path).readlines()]
        words = set(words) - set(stopw)
#         words = normal.filter_stop(words)
        return words
#train方法，用于训练数据，需要两个文本文件，分别是积极的数据文件和消极的数据文件
#分别将积极和消极文本文件中的数据进行处理，添加到data数据列表中
#最后使用classifier对象的训练数据对数据进行训练
#data为一个列表，其中每一个元素为列表[处理后的词语,词性]
    def train(self, neg_docs, pos_docs):
        data = []
        for sentence in neg_docs:
            data.append([self.handle(sentence), 'neg'])
        for sentence in pos_docs:
            data.append([self.handle(sentence), 'pos'])
        self.classifier.train(data)
#分类方法，返回的为情感是积极的概率,feeling为'pos'或'neg'，probability为概率
#classify方法，classifier对象调用classify方法对数据进行分类
    def classify(self, sentence):
        feeling, probability = self.classifier.classify(self.handle(sentence))
        if feeling == 'pos':
            return probability
        return 1-probability



#声明一个sentiment独享classifier,并调用读取方法（此处调用上面的方法）
classifier = Sentiment()
classifier.load()

#训练器，训练文件为积极消极文件
def train(neg_file, pos_file):
    neg_docs = codecs.open(neg_file, 'r', 'utf-8').readlines()
    pos_docs = codecs.open(pos_file, 'r', 'utf-8').readlines()
    global classifier
    classifier = Sentiment()
    classifier.train(neg_docs, pos_docs)


def save(fname, iszip=True):
    classifier.save(fname, iszip)


def load(fname, iszip=True):
    classifier.load(fname, iszip)


def classify(sent):
    return classifier.classify(sent)

# coding:utf-8
'''
Created on 2016年12月19日

@author: hao1160
'''
#文本相似度分析

"""
调节因子k1,b，其中k1为用于调节词语频率饱和度的速率，b为字段长度规约
词语频率饱和度是关键词的饱和出现次数，k1一般数值在1.2到2.0之间，数值越低则
饱和的过程越快
字段长度规约是将文档的长度归约化到全部文档的平均长度上，可以将不同长度的文档统
一到相同的比较条件上。它的值在 0 和 1 之间，1 意味着全部归约化，0 则不进行归约化。
"""
import operator 
import math
import jieba 
import os

class BM25(object):

#构造函数，声明一些变量
    def __init__(self, docs):
        #路径
        self.stopword_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         'sentiment\\stopwords.txt')
        #语料库中文档的数量
        self.D = len(docs)
        #文档的平均长度
        self.avgdl = 0.0
        for doc in docs:
            a = len(list(jieba.cut(doc)))
            self.avgdl = self.avgdl + a 
        self.avgdl = self.avgdl/self.D
#         self.avgdl = sum([len(doc)+0.0 for doc in docs]) / self.D
        self.docs = docs
        #用于保存词语在文档的次数，词频以列表形式，逐个追加
        self.f = []
        #文档的频率，统计每个词语在多少篇文档中出现
        self.df = {}
#         逆向文件频率的词典,idf可以由总文件数目除以包含该词语的文件的数目，再将得到的商取对数得到
        self.idf = {}
#       调节因子k1,b
        self.k1 = 1.5
        self.b = 0.75
        self.init()

#计算出每个词语的权重，使用idf作为权重指数
    def init(self):
        #计算出所有的关键词，保存到tmp词典中去，对每一篇文档循环结束后
        #添加到f的列表中
        for doc in self.docs:
            tmp = {}
            stopw = [line.strip().decode('utf-8') for line in open(self.stopword_path).readlines()]
            #将文档中所有的词语的出现次数进行统计，添加到temp词典中，并在没计算一篇文档后加入到f列表
            for word in list(set(jieba.cut(doc, cut_all=True)) - set(stopw)):
                if not word in tmp:
                    tmp[word] = 0
                tmp[word] += 1
            self.f.append(tmp)
            for k, v in tmp.items():  
                if k not in self.df:
                    self.df[k] = 0
                self.df[k] += 1
        for k, v in self.df.items():
            #idf的计算公式。v是包含该词的文档数，0.5是调教系数，避免v为0的情况
            #计算每个词语的idf用作权重
            self.idf[k] = math.log(self.D-v+0.5)-math.log(v+0.5)
#依次计算每篇文档的得分值，将每一个词语的分数累加，即得到整篇文档的分值
    def sim(self, doc, index):
        score = 0
        for word in list(jieba.cut(doc, cut_all=True)):
            if word not in self.f[index]:
                continue
            d = len(self.docs[index])
            #公式
            score += (self.idf[word]*self.f[index][word]*(self.k1+1)
                      / (self.f[index][word]+self.k1*(1-self.b+self.b*d
                                                      / self.avgdl)))
        return score
#返回所有相关性的值
    def simall(self, doc):
        scores = []
        for index in range(self.D):
            score = self.sim(doc, index)#分别计算与每个文档的相似度
            scores.append(score)
        return scores
    
#返回指定数量相似的下标
    def simMore(self, doc, num):
        scores = {}
        items = []
        chengyu = []
        for index in range(self.D):
            score = self.sim(doc, index)#分别计算与每个文档的相似度
            scores[index] = score
        sorted_x = sorted(scores.iteritems(), key=operator.itemgetter(1), reverse=True)
        for item in sorted_x:
            items.append(item[0]+1)
        return items[0:num] 
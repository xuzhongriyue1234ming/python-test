# coding:utf-8
'''
Created on 2016年12月19日

@author: hao1160
'''
import os
import xlrd
import sentiment
from sim import bm25

class Cheyu(object):
    
#初始化
    def __init__(self, doc):
        self.doc = doc
        #成语文件的相对路径
        self.path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'chengyu.xls')
        self.bm25 = bm25.BM25(doc)
        
#情感分析的调用
    @property
    def sentiments(self):
        return sentiment.classify(self.doc)
    
#返回评分最高的几个成语分值的下标，返回值为列表
    def simMore(self, doc, num):
        return self.bm25.simMore(doc, num)
    
#返回指定数量的成语，列表，内容为成语名称    
    def simChenyu(self, doc, num):
        data = xlrd.open_workbook(self.path)
        sequence = self.bm25.simMore(doc, num)
        #最相似的成语，列表，值为成语名称
        chengyus = []
        table = data.sheets()[0]  
        for seque in sequence:
            tmp = unicode(table.cell(seque-1,0).value)
            chengyus.append(tmp) 
        return chengyus
    
#返回指定成语的感情色彩，传入值为下标int

    def chengyuSenti(self, index):
        data = xlrd.open_workbook(self.path)
        table = data.sheets()[0]
        mean = unicode(table.cell(index-1,1).value)
        return sentiment.classify(mean)
        
        
# coding:utf-8
'''
Created on 2016年12月19日

@author: hao1160
'''

import xlrd
from chengyu.Idiom import Cheyu
import jieba
import os



class parse():
    def output(self,inputtext):
        #这一段是用来打开文件的
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chengyu\\chengyu.xls')
        data = xlrd.open_workbook(path)

        #最相似的
        chengyus = []
        table = data.sheets()[0]
        for i in range(table.nrows):
            tmp = unicode(table.cell(i,1).value)
            chengyus.append(tmp)
            #在上面的基础上，将数据做参数传给Cheyu对象
        s = Cheyu(chengyus)
        inputtext = raw_input('请输入一句话：')
        #调用方法，传入一句话，输出指定数量的列表，其中的数字为成语的下标
        print s.simMore(inputtext, 3)

        for word in s.simChenyu(inputtext, 3):
            print word
        return word


    #打印出来指定成语的褒义贬义（因为数据过少，现在不准确）
        print '褒义可能性：',s.chengyuSenti(1)
        print '褒义可能性：',s.chengyuSenti(2)
        print '褒义可能性：',s.chengyuSenti(3)
        print '褒义可能性：',s.chengyuSenti(4)
        print '褒义可能性：',s.chengyuSenti(5)






# coding:utf-8
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
import os
import locale
import Parse

class Newwindow(QDialog):
    def __init__(self,str_title,str_text,list_bool):#####自己写一个warningbox
        super(Newwindow,self).__init__(parent = None)
        gridlayout = QGridLayout()  # 创建布局组件
        self.return_value = list_bool
        self.setWindowTitle(str_title)
        self.mainlayout = QGridLayout(self)
        self.labelText = QLabel()
        self.setFont(QFont("Roman times",16))#####字体设置
        self.mainlayout.addWidget(self.labelText,0,0)
        self.labelText.setText(str_text)
        edit2 = QLineEdit()  # 创建单行文本框
        gridlayout.addWidget(edit2, 0, 1)
        edit2.setText(str_text)
        self.resize(400,100)
        inputtext = raw_input('请输入一句话：')
        m=Parse.output(inputtext)
        edit2.apend(m)


        self.setLayout(self.mainlayout)
        self.show()

class ui(QWidget):      # 通过继承QtGui.QWidget创建类
    def __init__(self):        # 初始化方法
        QWidget.__init__(self)    # 调用父类初始化方法

        self.setWindowTitle(u'成语推荐学习')     # 设置窗口标题
        self.resize(300,200)      # 设置窗口大小
        gridlayout = QGridLayout()   # 创建布局组件
        label1 = QLabel(u'请输入关键字') # 创建标签
        label1.setAlignment(Qt.AlignCenter)
        gridlayout.addWidget(label1, 0, 0 )
        edit1 = QLineEdit()     # 创建单行文本框
        gridlayout.addWidget(edit1, 0, 1)
        button1 = QPushButton(u'搜索')
        gridlayout.addWidget(button1, 0, 2)
        self.connect(button1, SIGNAL("clicked()"), self.slotSearch)
        self.setLayout(gridlayout)

    def slotSearch(self):
        list_run = []
        dilogUi = Newwindow(u"成语显示", u"成语显示", list_run)
        if dilogUi.exec_():
            return
        print list_run









app = QApplication(sys.argv)
form = ui()
form.show()
app.exec_()

